<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <title>Thông báo thành công</title>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel='stylesheet' type='text/css' media='screen' href='main.css'>
    <style>
        /* Quy tắc CSS tùy chỉnh cho trang này */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 5px;
            margin-top: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
        }

        h1 {
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 20px;
        }

        .message-container {
            margin-top: 20px;
        }

        .success-message {
            background-color: #4CAF50; /* Màu nền */
            color: #fff; /* Màu chữ */
            text-align: center; /* Căn giữa ngang */
            padding: 10px; /* Khoảng cách bên trong */
            border-radius: 5px; /* Góc bo tròn */
            margin: 20px auto; /* Căn giữa theo chiều ngang */
            max-width: 400px; /* Chiều rộng tối đa */
        }

        /* Thêm các quy tắc CSS tùy chỉnh khác tại đây */
        .info {
            background-color: #f0f0f0;
            border: 1px solid #ccc;
            border-radius: 5px;
            padding: 10px;
            font-size: 16px;
            color: #333;
            width: 300px;
            margin-left: 620px;
            margin-top: 20px;
        }

        .back-button {
            display: inline-block;
            margin-top: 20px;
            text-align: center;
            padding: 10px 20px;
            background-color: #007bff; /* Màu nền nút quay lại */
            color: #fff; /* Màu chữ nút quay lại */
            text-decoration: none;
            border-radius: 5px;
            margin-left: 620px;
        }

        .back-button:hover {
            background-color: #0056b3; /* Màu nền nút quay lại khi di chuột qua */
        }

    </style>
</head>
<body>
<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Thu thập dữ liệu từ biểu mẫu
    $name = $_POST["name"];
    $email = $_POST["email"];
    $std = $_POST["std"];
    $message = $_POST["message"];

    // Kết nối đến cơ sở dữ liệu MySQL
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "ctrlcgpt";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Kết nối thất bại: " . $conn->connect_error);
    }

    // Chuẩn bị và thực thi truy vấn để chèn dữ liệu
    $sql = "INSERT INTO contact_info (name, email, std, message) VALUES (?, ?, ?, ?)";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssss", $name, $email, $std, $message);
    
    if ($stmt->execute()) {
        echo "<div class='success-message'>Cảm ơn bạn đã sử dụng dịch vụ của ctrl/c !</div>";
        echo "<div class='info'>";
        echo "<h1>Thông tin bạn đã gửi:</h1>";
        echo "<p><strong>Họ và tên:</strong> " . $name . "</p>";
        echo "<p><strong>Địa chỉ Email:</strong> " . $email . "</p>";
        echo "<p><strong>Số ĐT ZALO:</strong> " . $std . "</p>";
        echo "<p><strong>Lời nhắc:</strong> " . $message . "</p>";
        echo "</div>";

        // Thêm nút quay lại
        echo "<a href='index.php' class='back-button'>Quay lại</a>";
    } else {
        echo "Lỗi khi thực thi truy vấn: " . $stmt->error;
    }

    // Đóng kết nối đến cơ sở dữ liệu
    $stmt->close();
    $conn->close();
}
?>

</body>
</html>
